
To run the assignment, just came into the folder where Makefile exist then -> 
    
     for answer1 : 
		run command  -> make ans1
			it will ask for a isocontour value, so enter a INTEGER value			 

     for answer2 : 
		run command -> make ans2
			it will ask, if you want to apply phong shading, so enter yes or no
