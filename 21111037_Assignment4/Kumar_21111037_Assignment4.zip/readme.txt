TO RUN THE CODE:
	python3 Kumar_21111037_Assignment4.py {percent_value} {reconstruction method [nearest, linear]}

	EXAMPLE: sample command to get output for the nearest with percent value of 1% :
		python3 Kumar_21111037_Assignment4.py 1 nearest


The above command will generate following output in command line: 
 
	Number of points in the dataset: 3125000
	Corner point indices: [0, 249, 62250, 62499, 3062500, 3062749, 3112749, 3124999]
	Number of additional points to sample: 31242
	Sampled points written to sampled_points.vtp
	Time taken : 5.527330160140991  secs
	Number of points in the dataset: 3125000
	SNR value is :  33.90877357444456

This will also generate following output files:
	
	reconstructed_data_nearest.vti
	POINTS_SAMPLED.vtp

